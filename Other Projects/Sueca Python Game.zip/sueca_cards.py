import sueca_suits_ranks as ssr


def parseCard(cs) :
    if ssr.valid_rank(cs[0]) and ssr.valid_suit(cs[1]) and len(cs) == 2 :
            return Card(cs[0], cs[1])
    else:
        raise CardInvalid(cs)

class Card :
    
    def __init__ (self, rank, suit) :
        self.rank = rank
        self.suit = suit
        
    def points(self) :
            current_points = ssr.rank_points(self.rank)
            return current_points
    
    def higher_than(self,other,s,t) :
        if ssr.valid_suit(s) and ssr.valid_suit(t) :
            #if self.suit == s and other.suit == s :
            if self.suit == other.suit:
                return ssr.rank_higher_than(self.rank,other.rank)
            elif self.suit == s and other.suit != t:
                return True
            elif other.suit != s and other.suit != t :
                return True
            elif self.suit == t :
                return True
            else:
                return False
                
        
    def show(self) :
        play = str(self.rank + self.suit)
        return play
    
class CardInvalid(Exception) :
    def __init__(self, current_card) :
        str = "The current card {c} is invalid."
        self.msg = str.format(c=current_card)
        super().__init__(self.msg)