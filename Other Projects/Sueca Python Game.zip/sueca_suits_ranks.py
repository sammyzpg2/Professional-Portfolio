
def valid_suit(s) :
    suits = ['C', 'D', 'H', 'S']
    if s in suits :
        return True
    else :
        return False

def valid_rank(r) :
    ranks = ['2', '3', '4', '5', '6', '7', 'Q', 'J', 'K', 'A']
    if r in ranks :
        return True
    else:
        return False


def suit_full_name(s) :
    cardSuit = str("")
    if s == "C" :
        cardSuit = ("Clubs")
    elif s == "D" :
        cardSuit = ("Diamonds")
    elif s == "H" :
        cardSuit = ("Hearts")
    elif s == "S" :
        cardSuit = ("Spades")
    else:
        raise ValueError("Invalid suit symbol " + s)
    return cardSuit

def rank_points(r):
    global points
    points = {'2': 0, '3': 0, '4': 0, '5': 0, '6': 0, 'Q': 2, 'J': 3, 'K': 4, '7': 10, 'A': 11}
    if r in points :
        cardValue = points[r]
        return cardValue
    else:
        raise ValueError("Invalid rank symbol " + r)

def rank_higher_than(r1, r2):
    
    if valid_rank(r1) == True and valid_rank(r2) == True :
            if rank_points(r1) > rank_points(r2) or list(points).index(r1) > list(points).index(r2):
                return True
            elif rank_points(r2) >= rank_points(r1) or list(points).index(r1) < list(points).index(r2) :
                return False
            
    else:
        raise ValueError("Invalid rank symbol(s) " + r1 + ", " + r2)
        