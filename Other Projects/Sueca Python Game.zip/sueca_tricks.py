import sueca_cards as sc

class Trick :
    
    def __init__(self, cards) :
        self.cards = [sc.parseCard(card) for card in cards]
        self.player = [1, 2, 3, 4]
        self.trump = ''
    
    def points(self) :
        return sum(card.points() for card in self.cards)
    
    def trick_winner(self, t):
        s = self.cards[0].suit
        winning_card = self.cards[0]
        winning_player = self.player[0]
        for i in range(1, len(self.cards)):
            if self.cards[i].higher_than(winning_card, s, t):
                winning_card = self.cards[i]
                winning_player = self.player[i]
        return winning_player
    
    
    def show(self) :
        return ' '.join(card.show() for card in self.cards)

def parseTrick(ts, min_tricks=1) :
    cards = ts.strip().split()
    if len(cards) != 4:
        raise ValueError("A trick string must comprise four cards only; the given trick is: " + ts)
    return Trick(cards)

def parseGameFile(fname) :
    with open(fname, 'r') as f:
        lines = f.readlines()
        if len(lines) < 1:
            raise ValueError("The game file must have at least one line for the trump card")
        if len(lines) > 11:
            raise ValueError("The game file must have at most 11 lines: 1 line for the trump card and 10 lines for the tricks")
        trump_card = sc.parseCard(lines[0].strip())
        tricks = []
        for line in lines[1:]:
            if line.strip():
                try:
                    tricks.append(parseTrick(line, trump_card.suit))
                except ValueError as error:
                 raise error
        return trump_card, tricks
