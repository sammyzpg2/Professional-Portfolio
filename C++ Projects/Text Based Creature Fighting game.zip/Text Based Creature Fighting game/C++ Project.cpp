#include "headers.h"


using namespace std;
const int CREATURE_NUMBER = 10;

class Creature {
protected:
    string name;
    int hitPoints;
    int maximumHP;
    int attack;
    int defense;
    int speed;

private:
    friend class Moves;
    // Privatizes the attributes of the class

public:
    Creature(string name, int hitPoints, int attack, int defense, int speed) :

        name(name),
        hitPoints(hitPoints),
        maximumHP(hitPoints),
        attack(attack),
        defense(defense),
        speed(speed)

    {}
    // Class constructor


    string getName() const {
        return name;
    } // Fetches name

    int getHP() const {
        return maximumHP;
    } // Fetches maximum HP

    int getCurrentHP() {
        return hitPoints;
    } // Fetches current HP

    void setCurrentHP(int newHP) {
        hitPoints = newHP;
    } // sets a new current HP

    int getAttack() const {
        return attack;
    } // Fetches attack

    void setAttack(int newAtk) {
        attack = newAtk;
    } // sets new attack

    int getDefense() const {
        return defense;
    } // Fetches defense

    void setDefense(int newDef) {
        defense = newDef;
    } // sets new defense

    int getSpeed() const {
        return speed;
    } // Fetches speed

    void setSpeed(int newSpd) {
        speed = newSpd;
    } // sets new speed





    void viewSummary() {
        cout << fixed << setprecision(1);
        cout << fixed << setw(3);
        cout << "Creature Summary: " << endl;
        cout << "Name: " << name << endl;
        cout << "Current HP: " << getCurrentHP() << "/" << maximumHP << endl;
        cout << "Attack: " << attack << endl;
        cout << "Defense: " << defense << endl;
        cout << "Speed: " << speed << endl;
        cout << endl;
    }


    bool moveOrder(Creature& activeComp) {
        srand(time(nullptr));
        int playSpeed = speed;
        int compSpeed = activeComp.speed;
        int playerSpeedOrder = (2 * playSpeed) + (rand() % 10);
        int enemySpeedOrder = (2 * compSpeed) + (rand() % 10);
        if (playerSpeedOrder >= enemySpeedOrder) {
            cout << "Player moves first." << endl;
            return true;
        }
        else {
            cout << "Enemy attacks first." << endl;
            return false;
        }
    }

    // Returns the values of the creature

    friend ostream& operator<< (ostream& out, const Creature& c)
    {
        out << "Name: " << c.name << " Hit Points: " << c.hitPoints << " Attack: " << c.attack << " Defense: " << c.defense << " Speed: " << c.speed << endl;
        return out;
    }
    // Overloads the Creature class to allow instances to be printed to an output stream.

    friend bool operator== (const Creature& c1, const Creature& c2) {
        return c1.name == c2.name;
    }
    // Overloads the Creature class to allow instances to be compared using the == operator.


};

class Moves {
private:
    string name;
    string attackName;
    int power;
    int accuracy;
    string effect;
    string moveInfo; // Class attributes

    friend class Creature; // Makes Creature a friend class

public:

    Moves(string name, string attackName, int power, int accuracy, string effect, string moveInfo) {
        this->name = name;
        this->attackName = attackName;
        this->power = power;
        this->accuracy = accuracy;
        this->effect = effect;
        this->moveInfo = moveInfo;
    } // Class Constructor

    string getAtkName() {
        return attackName;
    } // Fetches attackName

    int getPower() {
        return power;
    } // Fetches power

    int getAccuracy() {
        return accuracy;
    } // Fetches accuracy

    string getEffect() {
        return effect;
    } // Fetches effect

    string getInfo() {
        return moveInfo;
    } // Fetch moveInfo

    string getName() {
        return name;
    } // fetches name

    void reduceAttack(Creature& user, Creature& target) {
        cout << user.getName() << " lowered its opponent's attack!" << endl;
        int attack = ceil(target.getAttack() * 0.9);
        target.setAttack(attack);
    } // reduces target creature's attack

    void reduceDefense(Creature& user, Creature& target) {
        cout << user.getName() << " lowered its opponent's defense!" << endl;
        int defense = ceil(target.getDefense() * 0.9);
        target.setDefense(defense);
    } // reduces target creature's defense

    void reduceSpeed(Creature& user, Creature& target) {
        cout << user.getName() << " lowered its opponent's speed!" << endl;
        int speed = ceil(target.getSpeed() * 0.9);
        target.setSpeed(speed);
    } // reduces target creature's speed

    void raiseAttack(Creature& user) {
        cout << user.getName() << " raised its attack!" << endl;
        int attack = ceil(user.getAttack() * 1.1);
        user.setAttack(attack);
    } // raises user's attack

    void raiseDefense(Creature& user) {
        cout << name << " raised its defense!" << endl;
        int defense = ceil(user.getDefense() * 1.1);
        user.setDefense(defense);
    } // raises user's attack

    void raiseSpeed(Creature& user) {
        cout << name << " raised its speed!" << endl;
        int speed = ceil(user.getSpeed() * 1.1);
        user.setSpeed(speed);
    } // raises user's attack

    void heal(Creature& user) {
        int maxHP = user.getHP();
        int currentHP = user.getCurrentHP();
        int healedHP = maxHP / 2;
        int newHP = min(maxHP, currentHP + healedHP);
        if (newHP > maxHP) {
            cout << name << " is exceeding full health!" << endl;
        }
        else {
            cout << name << " healed " << healedHP << " damage." << endl;
        }
        user.setCurrentHP(newHP);
    } // heals the user by 50%

    void noEffect() {} // does nothing if there is no effect

    void doEffect(string effect, Creature& user, Creature& target) {
        if (effect == " reduceAttack") {
            this->reduceAttack(user, target);
        }
        else if (effect == " reduceDefense") {
            this->reduceDefense(user, target);
        }
        else if (effect == " reduceSpeed") {
            this->reduceSpeed(user, target);
        }
        else if (effect == " raiseAttack") {
            raiseAttack(user);
        }
        else if (effect == " raiseDefense") {
            this->raiseDefense(user);
        }
        else if (effect == " raiseSpeed") {
            this->raiseSpeed(user);
        }
        else if (effect == " heal") {
            this->heal(user);
        }
        else if (effect == " noEffect") {
            this->noEffect();
        }
        else {
            this->noEffect();
        }
    } // directs what method to use based on effect

    void useMove(Creature& user, Creature& target) {
        cout << user.getName() << " used" << attackName << endl;
        int damage = ((15 * user.getAttack() * power) / (15 * target.getDefense()) + 2);
        cout << "The attack did " << damage << " damage." << endl;
        int currentHP = (target.getCurrentHP() - damage);
        target.setCurrentHP(currentHP);
        this->doEffect(effect, user, target);


    } // uses the move, calculates damage and applies it to the HP.

    friend ostream& operator<< (ostream& out, const Moves& d)
    {
        out << "Creature Name: " << d.name << " Attack name: " << d.attackName << " Power: " << d.power << " Accuracy: " << d.accuracy << " Extra effect:" << d.moveInfo << endl;
        return out;
    } // overrides string to output an object as shown
};

bool doesHit(Creature& attacker, Creature& defender, Moves& move) {
    double hitChance = static_cast<double>(move.getAccuracy()) / defender.getSpeed();
    if (move.getAccuracy() == 100) {
        if (attacker.getSpeed() > defender.getSpeed()) {
            hitChance *= 2.0;
        }
        else if (attacker.getSpeed() < defender.getSpeed()) {
            hitChance /= 2.0;
        }
    }
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_real_distribution<double> dis(0.0, 1.0);
    return (dis(gen) < hitChance);
} // Determine whether the attack hits or not, to then call on the relevant functions

void PlayerWon() {

} // Player win

void PlayerLost() {

} // Player lost



int main()
{

    ifstream inputFile("Stats Creatures.txt"); // Opens the text file with the creature information.
    if (!inputFile.is_open()) {
        cout << "Unable to open file";
        return 0;
    }
    // Checks if the file is open

    string line;
    vector<Creature> CreatArray;
    for (int i = 0; i < CREATURE_NUMBER; i++) {
        if (inputFile.is_open()) {
            string line;
            getline(inputFile, line);
            stringstream ss(line);
            string nom, hp, atk, def, spd;
            getline(ss, nom, ',');
            getline(ss, hp, ',');
            getline(ss, atk, ',');
            getline(ss, def, ',');
            getline(ss, spd);
            Creature creature(nom, stoi(hp), stoi(atk), stoi(def), stoi(spd));
            CreatArray.push_back(creature);

        } // reads file line by line, separating each line into each of the attributes, creating an object and appending it to vector CreatArray
    }

    ifstream moveFile("Stats Moves.txt");
    string line1;
    vector<Moves> MovesArray;
    const int MOVES_NUMBER = 30;
    for (int p = 0; p < MOVES_NUMBER; p++) {
        if (moveFile.is_open()) {
            string line1;
            getline(moveFile, line1);
            stringstream mo(line1);
            string naam, atkName, pwr, acc, eff, info;
            getline(mo, naam, ',');
            getline(mo, atkName, ',');
            getline(mo, pwr, ',');
            getline(mo, acc, ',');
            getline(mo, eff, ',');
            getline(mo, info);
            Moves move(naam, atkName, stoi(pwr), stoi(acc), eff, info);
            MovesArray.push_back(move);

        } // reads file line by line, separating each line into each of the attributes, creating an object and appending it to vector CreatArray
    }

    moveFile.close();
    inputFile.close();

    int teamSize;
    cout << "Enter how large you would like the size of your team to be (1-10): ";
    cin >> teamSize; // inputs how large the teams will be
    while (cin.fail() || teamSize > 10 || teamSize < 1) {
        std::cin.clear(); // reset state
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
        cout << "Invalid input. Please enter a number between 1 to 10. " << endl;
        cout << "Enter how large you would like the size of your team to be (1-10): ";
        cin >> teamSize;
    } // checks for an valid input

    vector<Creature> myTeam;
    vector<Creature> compTeam;

    repick: // matches a goto
    cout << "This is the list of all the creatures to pick from:" << endl;
    for (int j = 0; j < CREATURE_NUMBER; j++) {
        cout << j + 1 << ": " << CreatArray[j].getName() << endl;
    } // Output =s all available creatures

    int CreatureSelect;
    string confirmTeam;

    for (int k = 0; k < teamSize; k++) {
        cout << "Please select which creature you would like to use by writing its number: ";
        cin >> CreatureSelect; // selects which creature to append to myTeam
        while (cin.fail() || CreatureSelect < 1 || CreatureSelect > CREATURE_NUMBER || CreatureSelect > INT_MAX) {
            std::cin.clear(); // reset state
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            cout << "Invalid input, please input a number between 1 and " << CREATURE_NUMBER << ": ";
            cin >> CreatureSelect; // Makes sure an valid input is inputted.

        }

        while (std::count(myTeam.begin(), myTeam.end(), CreatArray[CreatureSelect - 1]) >= 1) {
            cout << "This creature has been selected before, please choose again: ";
            cin >> CreatureSelect;
        } // MAkes sure the same creature is not chosen twice

        myTeam.push_back(CreatArray[CreatureSelect - 1]); // appends selected creature to myTeam
    }


    this_thread::sleep_for(chrono::seconds(1));
    cout << "Your selected team: " << endl;
    for (int m = 0; m < myTeam.size(); m++) {

        cout << myTeam[m].getName() << endl;
    } // outputs selected team

    cout << endl;
    cout << "Are you happy with this team? (y/n) ";
    cin >> confirmTeam; // checks if the user is happy with their team
    bool validInput = false;
    while (!validInput) {
        if (confirmTeam == "n" || confirmTeam == "N") {
            validInput = true;
            cout << "Please wait..." << endl;
            this_thread::sleep_for(chrono::seconds(2));
            myTeam.clear();
            system("cls");
            goto repick;
        } // Paces out game and clears console
        else if (confirmTeam == "y" || confirmTeam == "Y") {
            validInput = true;
        } // carries on the code
        else {
            std::cin.clear(); // reset state
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            cout << "Invalid input. Please try again." << endl;
            cout << "Are you happy with this team? (y/n) ";
            cin >> confirmTeam;
        } // checks for valid input
    }
    srand(time(nullptr)); // makes sure that rand() generates different numbers each time
    int compSelect;
    for (int n = 0; n < teamSize; n++) {
        compSelect = rand() % CREATURE_NUMBER + 1;
        while (count(compTeam.begin(), compTeam.end(), CreatArray[compSelect - 1]) >= 1) {
            compSelect = rand() % CREATURE_NUMBER;
        }
        compTeam.push_back(CreatArray[compSelect - 1]);
    } // selects computer's team

    cout << endl;

    cout << endl;
    cout << "Please wait..." << endl;;
    this_thread::sleep_for(chrono::seconds(3));
    system("cls"); // clears console, paces out games

    string opptNames[13] = { "Jesse", "Robert", "Olivia", "Juan", "Glacia", "Alexander", "Stuart", "Leah", "Michael", "Rebecca", "Ian", "Juliet", "James" };
    int opptName;
    opptName = rand() % 13;
    cout << "Player " << opptNames[opptName - 1] << " wants to battle!" << endl; // picks a name for the computer and outputs it in the game

    cout << "Player sent out " << myTeam[0].getName() << "!" << endl;
    this_thread::sleep_for(chrono::seconds(1));
    cout << opptNames[opptName - 1] << " sent out " << compTeam[0].getName() << "!" << endl; // Sends out first creature of each vector

    cout << endl;


    Creature& currentPlay = myTeam[0]; // sets active creature to first object in the vector
    Creature& currentComp = compTeam[0]; // sets active creature to first object in the vector
    vector<Moves> activePlayCreat; // player's creature's moves
    vector<Moves> compPlayCreat; // player's creature's moves


    int playerRemain = teamSize;
    int compRemain = teamSize;
    int switchSelect;
    int switchIn;
    int turnChoice;
    int moveChoice;
    int switchChoice;
    bool validInput2 = false;
    string endGame; // defines all necessary variables for game loop

    while (playerRemain != 0 && compRemain != 0) {
        cout << "Player Remain: " << playerRemain << endl;
        cout << "Comp Remain: " << compRemain << endl;
    choice:
        int maxHP = find_if(CreatArray.begin(), CreatArray.end(), [&](const Creature& cr) { return cr.getName() == currentPlay.getName(); }) - CreatArray.begin(); //finds the maxHP of the creature from creatArray.
        int comMaxHP = find_if(CreatArray.begin(), CreatArray.end(), [&](const Creature& cr) { return cr.getName() == currentComp.getName(); }) - CreatArray.begin(); // finds maxHP of creature from CreatArray for computer
        activePlayCreat.clear(); // lcears moves arrays
        compPlayCreat.clear();
        copy_if(MovesArray.begin(), MovesArray.end(), back_inserter(activePlayCreat), [&](Moves& mov) { return mov.getName() == currentPlay.getName(); }); // copies all objects from MovesArray where name is equal to currentPlay's name
        copy_if(MovesArray.begin(), MovesArray.end(), back_inserter(compPlayCreat), [&](Moves& mov) { return mov.getName() == currentComp.getName(); }); // copies all objects from MovesArray where name is equal to currentPlay's name


        cout << "Active Foe's Creature: " << currentComp.getName() << endl;
        cout << "Foe's Current HP: " << currentComp.getCurrentHP() << "/" << CreatArray[comMaxHP].getHP() << endl;
        cout << "Active Creature: " << currentPlay.getName() << endl;
        cout << "Current HP: " << currentPlay.getCurrentHP() << "/" << currentPlay.getHP() << endl; // outputs the current stat.

        cout << "What would you like to do, write the number you would like:" << endl;
        cout << "1: Attack" << endl;
        cout << "2: Summary" << endl;
        cout << "3: Switch" << endl;
        cout << "4: Concede" << endl;
        cin >> turnChoice; // input what you like 
        if (cin.fail()) {
            std::cin.clear(); // reset state
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            cout << "Invalid input, please enter a valid input." << endl;
            goto choice;
        } // checks for valid input

        while (!validInput2) {


            if (turnChoice == 1) {
                cout << "Please pick a move: " << endl;
                for (int r = 0; r < activePlayCreat.size(); r++) {
                    cout << r + 1 << ": " << activePlayCreat[r].getAtkName() << "\t" << "Effect: " << activePlayCreat[r].getInfo() << endl;
                } // lists out all the creature's move
                cin >> moveChoice;
                int compTurnChoice = (rand() % (compPlayCreat.size()));
                bool speedOrder = currentPlay.moveOrder(currentComp);
                if (speedOrder == true) {
                    cout << currentPlay.getName() << " used " << activePlayCreat[moveChoice - 1].getAtkName() << endl;
                    if (activePlayCreat[moveChoice - 1].getPower() == 0) {
                        activePlayCreat[moveChoice - 1].doEffect(activePlayCreat[moveChoice - 1].getEffect(), currentPlay, currentComp);
                    }
                    else {
                        if (doesHit(currentPlay, currentComp, activePlayCreat[moveChoice - 1])) {
                            cout << currentPlay;
                            cout << currentComp;
                            activePlayCreat[moveChoice - 1].useMove(currentPlay, currentComp);
                        }
                        else {
                            cout << currentPlay.getName() << " used " << activePlayCreat[moveChoice - 1].getAtkName() << endl;
                            cout << "The attack missed!" << endl;
                        }
                    } // checks if computer's attack hits, and executes attack if it does

                    cout << endl;
                    this_thread::sleep_for(chrono::seconds(1));

                    if (doesHit(currentComp, currentPlay, compPlayCreat[compTurnChoice - 1])) {

                        compPlayCreat[compTurnChoice - 1].useMove(currentComp, currentPlay);
                        if (!(currentComp.getCurrentHP() <= 0 || currentPlay.getCurrentHP() <= 0)) {
                            goto choice;
                        }       
                    }
                    else {
                        cout << currentComp.getName() << " used " << compPlayCreat[moveChoice - 1].getAtkName() << endl;
                        cout << "The foe's attack missed!" << endl;
                        if (!(currentComp.getCurrentHP() <= 0 || currentPlay.getCurrentHP() <= 0)) {
                            goto choice;
                        }

                    } // checks if computer's attack hits, and executes attack if it does
                }
                else {
                    cout << currentComp.getName() << " used " << compPlayCreat[moveChoice - 1].getAtkName() << endl;
                    if (doesHit(currentComp, currentPlay, compPlayCreat[compTurnChoice - 1])) {
                        cout << "Comp Turn Choice: " << compTurnChoice << endl;
                        cout << "CompPlayCreat Size: " << compPlayCreat.size() << endl;
                        compPlayCreat[compTurnChoice - 1].useMove(currentComp, currentPlay);
                    }
                    else {
                        cout << currentComp.getName() << " used " << compPlayCreat[moveChoice - 1].getAtkName() << endl;
                        cout << "The foe's attack missed!" << endl;
                    }

                    cout << endl;
                    if (doesHit(currentPlay, currentComp, activePlayCreat[moveChoice - 1])) {
                        activePlayCreat[moveChoice - 1].useMove(currentPlay, currentComp);
                        if (!(currentComp.getCurrentHP() <= 0 || currentPlay.getCurrentHP() <= 0)) {
                            goto choice;
                        }

                    }
                    else {
                        cout << "The attack missed!" << endl;
                        if (!(currentComp.getCurrentHP() <= 0 || currentPlay.getCurrentHP() <= 0)) {
                            goto choice;
                        }
                    } // same as above however is for if computer moves first
                }

                if (currentPlay.getCurrentHP() <= 0) {
                    cout << currentPlay.getName() << " has been knocked out!" << endl;
                    playerRemain -= 1;
                    string unconName = currentPlay.getName();

                    myTeam.erase(remove_if(myTeam.begin(), myTeam.end(), [unconName](const Creature& ct) { return ct.getName() == unconName; }), myTeam.end());
                    if (myTeam.size() == 0) {
                        cout << "The opponent has won the battle." << endl;
                        break;
                    }
                    cout << "Please pick another creature to replace your creature:" << endl;
                    for (int s = 0; s < myTeam.size(); s++) {
                        cout << s + 1 << ": " << myTeam[s].getName() << endl;
                    }
                    cin >> switchIn;
                    currentPlay = myTeam[switchIn - 1];
                    goto choice;
                } // checks if currentPlay is knocked out
                else if (currentComp.getCurrentHP() <= 0) {
                    cout << currentComp.getName() << " has been knocked out!" << endl;
                    compRemain -= 1;
                    string unconName = currentComp.getName();

                    compTeam.erase(remove_if(compTeam.begin(), compTeam.end(), [unconName](const Creature& ct) { return ct.getName() == unconName; }), compTeam.end());

                    if (compTeam.size() == 0 && !(myTeam.size() == 0)) {
                        cout << "Congratulations on winning!";
                        break;
                    }
                    else if (compTeam.size() == 0 && myTeam.size() == 0) {
                        cout << "Both teams passed out! What a close one folks.";
                        break;
                    }
                    else {
                        currentComp = compTeam[0];
                        comMaxHP = find_if(CreatArray.begin(), CreatArray.end(), [&](const Creature& cr) { return cr.getName() == currentComp.getName(); }) - CreatArray.begin();

                        cout << opptNames[opptName - 1] << " sent out " << currentComp.getName() << endl;
                    }
                } // checks if currentComp is knocked out
            }
            else if (turnChoice == 2) {
                currentPlay.viewSummary();
                goto choice;
            } // outputs the creature's summary

            else if (turnChoice == 3) {
                int storedHP = currentPlay.getCurrentHP();
                cout << "Which creature would you like to switch into? Enter their number. " << endl;
                for (int q = 0; q < myTeam.size(); q++) {
                    cout << q + 1 << ": " << myTeam[q].getName() << endl;
                }
                cin >> switchSelect; // outputs all other creatures in myTeam, prompts the selection one to swap into
                switchSelect--;
            choose:
                cout << "What would you like to do: " << endl;
                cout << "1: Swap In" << endl;
                cout << "2: Summary" << endl;
                cout << "3: Cancel" << endl; // presents options for actions with selected creature
                cin >> switchChoice;
                if (switchChoice == 1) {
                    int currentHP1 = currentPlay.getCurrentHP();

                    Creature temp = currentPlay;
                    for (int t = 0; t < myTeam.size(); t++) {
                        cout << myTeam[t] << endl;
                    }
                    cout << "Current Creature: " << temp << endl;
                    currentPlay = myTeam[switchSelect];
                    for (int t = 0; t < myTeam.size(); t++) {
                        cout << myTeam[t] << endl;
                    }
                    myTeam[switchSelect] = temp;

                    cout << "Come back, " << temp.getName() << ". Come on out, " << currentPlay.getName() << "!" << endl;

                    goto choice;
                } // replaces currentPlay content with object of creature with the name of the selected creature
                else if (switchChoice == 2) {
                    myTeam[switchSelect - 1].viewSummary();
                    goto choice;

                } // outputs selected creature's summary
                else if (switchChoice == 3) {
                    goto choice;
                } // cancels the action

            }
            else if (turnChoice == 4) {
                cout << "Are you sure you would like to concede, this will end the game. (y/n)" << endl;
                cin >> endGame; // checks if the player is sure for conceding
                while (!validInput2) {
                    if (endGame == "y") {
                        cout << "Player conceded, " << opptNames[opptName] << " wins." << endl;
                        this_thread::sleep_for(chrono::seconds(1));
                        cout << "Thank you for playing!" << endl;
                        return 0;
                    } // ends the game, computer wins
                    else if (endGame == "n") {
                        cout << "Resuming Game..." << endl;
                        this_thread::sleep_for(chrono::seconds(1));
                        goto choice;
                    } // resets the game loop
                    else {
                        cout << "Invalid input. Please input 'y' or 'n'" << endl;
                        cout << "Are you sure you would like to concede, this will end the game." << endl;
                        cin >> endGame;
                    } //  checks for valid input.
                }
            }
        }
    }
}

